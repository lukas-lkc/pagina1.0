var comprarAgora = "https://hotmart.com"

function changeVideo(videoId) {
  var video = document.getElementById("video1");
    video.src = "https://www.youtube.com/embed/" + videoId;
  }
function redirect() {
  window.location.href = comprarAgora;
}